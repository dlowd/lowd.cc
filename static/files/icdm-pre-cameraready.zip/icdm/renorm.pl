#!/usr/bin/perl -w
while(<>)
{
  @l = split;
  for $i (0..4) {
    print $l[$i]/$l[5];
    print " ";
  }
  print "\n";
}
